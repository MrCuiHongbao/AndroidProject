package cn.ubeta.gles_plugin;

import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.GLSurfaceView;
import android.util.Log;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

import static javax.microedition.khronos.egl.EGL10.EGL_DRAW;

public class GLESEGL implements GLSurfaceView.EGLContextFactory, GLSurfaceView.EGLConfigChooser  {

    private EGL10 mEgl;
    private EGLDisplay mEGLDisplay = EGL10.EGL_NO_DISPLAY;
    private EGLContext mEGLContext = EGL10.EGL_NO_CONTEXT;
    private EGLSurface mEglSurface;

    private int mRedSize,
            mGreenSize,
            mBlueSize,
            mAlphaSize,
            mDepthSize,
            mStencilSize;

    public GLESEGL() {
        mRedSize = 8;
        mGreenSize = 8;
        mBlueSize = 8;
        mAlphaSize = 8;
        mDepthSize = 16;
        mStencilSize = 0;
    }

    @Override
    public EGLContext createContext(EGL10 egl, EGLDisplay display, EGLConfig eglConfig) {
        int[] attrs = {
                EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
                EGL10.EGL_NONE
        };
        EGLContext context = egl.eglCreateContext(display, eglConfig, EGL10.EGL_NO_CONTEXT, attrs);
        return context;
    }

    @Override
    public void destroyContext(EGL10 egl, EGLDisplay eglDisplay, EGLContext context) {
        egl.eglMakeCurrent(eglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
        egl.eglDestroySurface(eglDisplay, mEglSurface);
        egl.eglDestroyContext(eglDisplay, context);
        egl.eglTerminate(eglDisplay);
    }

    @Override
    public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
        int[] num_config = new int[1];
        int[] s_configAttribs =
                {
                        EGL10.EGL_RED_SIZE, 5,
                        EGL10.EGL_GREEN_SIZE, 6,
                        EGL10.EGL_BLUE_SIZE, 5,
                        EGL10.EGL_ALPHA_SIZE, 0,
                        EGL10.EGL_RENDERABLE_TYPE, 4,
                        EGL10.EGL_SAMPLES, 4,
                        EGL10.EGL_NONE
                };

        egl.eglChooseConfig(display, s_configAttribs, null, 0, num_config);

        int numConfigs = num_config[0];

        EGLConfig[] configs = new EGLConfig[numConfigs];

        egl.eglChooseConfig(display, s_configAttribs, configs, numConfigs, num_config);

        return chooseConfig(egl, display, configs);
    }

    private EGLConfig chooseConfig(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
        for (EGLConfig config : configs) {
            int depth = findConfigAttrib(egl, display, config, EGL10.EGL_DEPTH_SIZE, 0);
            int stencil = findConfigAttrib(egl, display, config, EGL10.EGL_STENCIL_SIZE, 0);

            if (depth < mDepthSize || stencil < mStencilSize) {
                continue;
            }

            int r = findConfigAttrib(egl, display, config, EGL10.EGL_RED_SIZE, 0),
                    g = findConfigAttrib(egl, display, config, EGL10.EGL_GREEN_SIZE, 0),
                    b = findConfigAttrib(egl, display, config, EGL10.EGL_BLUE_SIZE, 0),
                    a = findConfigAttrib(egl, display, config, EGL10.EGL_ALPHA_SIZE, 0);

            if (r == mRedSize && g == mGreenSize && b == mBlueSize && a == mAlphaSize) {
                return config;
            }
        }

        return null;
    }

    private int findConfigAttrib(EGL10 egl, EGLDisplay display, EGLConfig config, int attribute, int defaultValue) {
        int[] mValue = new int[1];

        if (egl.eglGetConfigAttrib(display, config, attribute, mValue)) {
            return mValue[0];
        } else {
            return defaultValue;
        }
    }

    /**
     * 初始化EGL
     */
    public void init(SurfaceTexture surfaceTexture) {
        mEgl = (EGL10) EGLContext.getEGL();

        mEGLDisplay = mEgl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
        if (mEGLDisplay == EGL10.EGL_NO_DISPLAY) {
            throw new RuntimeException("eglGetDisplay failed! " + mEgl.eglGetError());
        }

        int[] version = new int[2];
        if (!mEgl.eglInitialize(mEGLDisplay, version)) {
            throw new RuntimeException("eglInitialize failed! " + mEgl.eglGetError());
        }

        if (surfaceTexture != null) {
            EGLConfig eglConfig = chooseConfig(mEgl, mEGLDisplay);

            mEglSurface = mEgl.eglCreateWindowSurface(mEGLDisplay, eglConfig, surfaceTexture, null);
            //mEglSurface = mEgl.eglGetCurrentSurface(EGL_DRAW);

            mEGLContext = createContext(mEgl, mEGLDisplay, eglConfig);
            //mEGLContext = mEgl.eglGetCurrentContext();

            if (mEGLDisplay == EGL10.EGL_NO_DISPLAY || mEGLContext == EGL10.EGL_NO_CONTEXT) {
                throw new RuntimeException("eglCreateContext fail failed! " + mEgl.eglGetError());
            }

            if (!mEgl.eglMakeCurrent(mEGLDisplay, mEglSurface, mEglSurface, mEGLContext)) {
                throw new RuntimeException("eglMakeCurrent failed! " + mEgl.eglGetError());
            }
        }
    }

    public void swapBuffers() {
        mEgl.eglSwapBuffers(mEGLDisplay, mEglSurface);
    }

    /**
     * 销毁
     */
    public void destroy() {
        destroyContext(mEgl, mEGLDisplay, mEGLContext);
    }
}
