package cn.ubeta.gles_plugin;

import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.util.Log;
import android.util.Size;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.Arrays;

import cn.ubeta.gles_plugin.GLESEGL;
import cn.ubeta.gles_plugin.SkyboxFilter;

import static android.os.Process.THREAD_PRIORITY_DEFAULT;

public class GLESThread extends HandlerThread {

    private static final int MSG_INIT = 1;
    private static final int MSG_LOAD_MODEL = 2;
    private static final int MSG_RENDER = 3;
    private static final int MSG_RESIZE = 4;
    private static final int MSG_EXIT = 5;

    private Handler mHandler;
    private SurfaceTexture mSurfaceTexture;
    private GLESEGL mEgl = new GLESEGL();
    private SkyboxFilter mFilter;

    private Context mContext;
    private String mCameraId;
    Size mPreviewSize = null;
    CaptureRequest.Builder mCaptureRequestBuilder = null;

    private boolean mRunning;

    public GLESThread(Context context, String name, SurfaceTexture surfaceTexture, int width, int height) {
        this(context, name, surfaceTexture, width, height, THREAD_PRIORITY_DEFAULT);
    }

    public GLESThread(Context context, String name, SurfaceTexture surfaceTexture, int width, int height, int priority) {
        super(name, priority);
        mContext = context;
        mRunning = false;
        mSurfaceTexture = surfaceTexture;
        surfaceTexture.setDefaultBufferSize(width, height);
        start();
        onSurfaceTextureAvailable(surfaceTexture, width,height);
    }

    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
        mHandler = new Handler(getLooper()) {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case MSG_INIT:
                        init(msg.arg1, msg.arg2);
                        break;
                    case MSG_LOAD_MODEL:
                        try {
                            String[] token = ((String) msg.obj).split(",");
                            String fileName = token[0];
                            String password = token[1]; // "@Jdnb123"
                            int operatorId = Integer.parseInt(token[2]);

//                            if (frostfireLoadModel(fileName, password, operatorId)) {
//                                sendEmptyMessage(MSG_RENDER);
//                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case MSG_RENDER:
                        if (mRunning) {
                            onDraw();
                            sendEmptyMessage(MSG_RENDER);
                        }
                        break;
                    case MSG_RESIZE:
                        onResize(msg.arg1, msg.arg2);
                        break;
                    case MSG_EXIT:
                        onDestroy();
                        break;
                    default:
                        return;
                }
            }
        };

        mRunning = true;

        Message msg = Message.obtain();
        msg.what = MSG_INIT;
        msg.arg1 = width;
        msg.arg2 = height;
        mHandler.sendMessage(msg);
    }

    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int width, int height) {
        Message msg = Message.obtain();
        msg.what = MSG_RESIZE;
        msg.arg1 = width;
        msg.arg2 = height;
        mHandler.sendMessage(msg);
    }

    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        if (mEgl != null) {
            mEgl.destroy();
        }
        mHandler.sendEmptyMessage(MSG_EXIT);
        quit();
        return true;
    }

    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        mHandler.sendEmptyMessage(MSG_RENDER);
    }

    /**
     * 初始化
     */
    void init(int width, int height) {
        mEgl.init(mSurfaceTexture);
        mFilter = new SkyboxFilter();
        mHandler.sendEmptyMessage(MSG_RENDER);

        android.hardware.camera2.CameraManager manager = (android.hardware.camera2.CameraManager) mContext.getSystemService(Context.CAMERA_SERVICE);
        try {
            //遍历所有摄像头
            for (String cameraId: manager.getCameraIdList()) {
                CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
                //默认打开后置摄像头
                if (characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT)
                    continue;
                //获取StreamConfigurationMap，它是管理摄像头支持的所有输出格式和尺寸
                StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                //根据TextureView的尺寸设置预览尺寸
                //mPreviewSize = getOptimalSize(map.getOutputSizes(SurfaceTexture.class), width, height);
                Size sizes[] = map.getOutputSizes(SurfaceTexture.class);
//                for (int i = 0; i < map.getOutputSizes(SurfaceTexture.class).length; ++i) {
//                    Log.e("size", "mPreviewSize " + sizes[i].getWidth() + "x" + sizes[i].getHeight());
//                }
                mPreviewSize = sizes[0];
                mCameraId = cameraId;
                break;
            }

            //打开相机，第一个参数指示打开哪个摄像头，第二个参数stateCallback为相机的状态回调接口，第三个参数用来确定Callback在哪个线程执行，为null的话就在当前线程执行
            manager.openCamera(mCameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    CameraDevice mCameraDevice = camera;
                    //开启预览
                    //startPreview();

                    //前三个参数分别是需要的尺寸和格式，最后一个参数代表每次最多获取几帧数据，本例的2代表ImageReader中最多可以获取两帧图像流
                    ImageReader mImageReader = ImageReader.newInstance(mPreviewSize.getWidth(), mPreviewSize.getHeight(),
                            ImageFormat.JPEG, 2);
                    //监听ImageReader的事件，当有图像流数据可用时会回调onImageAvailable方法，它的参数就是预览帧数据，可以对这帧数据进行处理
                    mImageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                        @Override
                        public void onImageAvailable(ImageReader reader) {
                            Image image = reader.acquireLatestImage();
                            //我们可以将这帧数据转成字节数组，类似于Camera1的PreviewCallback回调的预览帧数据
                            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                            byte[] data = new byte[buffer.remaining()];
                            buffer.get(data);
                            image.close();
                            Log.e("size", "onImageAvailable ");
                        }
                    }, null);

                    //获取ImageReader的Surface
                    Surface imageReaderSurface = mImageReader.getSurface();

                    //创建CaptureRequestBuilder，TEMPLATE_PREVIEW比表示预览请求
                    try {
                        mCaptureRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                    //设置Surface作为预览数据的显示界面
                    //mCaptureRequestBuilder.addTarget(imageReaderSurface);

                        Surface surface = new Surface(mSurfaceTexture);
                        mCaptureRequestBuilder.addTarget(surface);

                    //创建相机捕获会话，第一个参数是捕获数据的输出Surface列表，第二个参数是CameraCaptureSession的状态回调接口，当它创建好后会回调onConfigured方法，第三个参数用来确定Callback在哪个线程执行，为null的话就在当前线程执行
                    mCameraDevice.createCaptureSession(Arrays.asList(surface), new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession session) {
                            try {
                                //创建捕获请求
                                CaptureRequest mCaptureRequest = mCaptureRequestBuilder.build();
                                CameraCaptureSession mPreviewSession = session;
                                //设置反复捕获数据的请求，这样预览界面就会一直有数据显示
                                mPreviewSession.setRepeatingRequest(mCaptureRequest, new CameraCaptureSession.CaptureCallback() {
                                }, null);
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession session) {

                        }
                    }, null);

                } catch (CameraAccessException e) {
                    e.printStackTrace();
                }
                }

                @Override
                public void onDisconnected(CameraDevice camera) {

                }

                @Override
                public void onError(CameraDevice camera, int error) {

                }
            }, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    /**
     * 窗口大小
     */
    void onResize(int width, int height) {
        if (mFilter != null) {
            mFilter.onSizeChanged(width, height);
        }
    }

    /**
     * 销毁　
     */
    void onDestroy() {
        // TODO 销毁
    }

    /**
     * 渲染
     */
    private void onDraw() {
        if (mFilter != null) {
            mFilter.onDraw();
            mEgl.swapBuffers();
        }
    }

    public void setRotationMatrix(float rotationMatrix[]) {
        if (mFilter != null) {
            mFilter.setRotationMatrix(rotationMatrix);
        }
    }
}
