package cn.ubeta.gles_plugin;

import android.opengl.GLES20;
import android.opengl.Matrix;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class SkyboxFilter {

    private static final int COORDS_PER_VERTEX = 3;

    private static final String mVertexShader = "" +
            "uniform mat4 uMatrix;" +
            "attribute vec3 aPosition;" +
            "varying vec3 vPosition;" +
            "void main() {" +
            "  vPosition = aPosition;" +
            "  vPosition.z = -vPosition.z;" +
            "  gl_Position = uMatrix * vec4(aPosition, 1.0);" +
            //"  gl_Position = gl_Position.xyww;" +
            "  gl_Position.z = gl_Position.w;" +
            //"  gl_Position.z = gl_Position.w / 2.0;" +
            "}";

    private static final String mFragmentShader = "" +
            "precision mediump float;" +
            "uniform samplerCube uTextureUnit;" +
            "varying vec3 vPosition;" +
            "void main() {" +
            "  gl_FragColor = textureCube(uTextureUnit, vPosition);" +
            "}";

    // 立方体坐标
    private static final float[] CubeCoords = new float[] {
            -1,  1,  1,     // (0) Top-left near
            1,   1,  1,     // (1) Top-right near
            -1, -1,  1,     // (2) Bottom-left near
            1,  -1,  1,     // (3) Bottom-right near
            -1,  1, -1,     // (4) Top-left far
            1,   1, -1,     // (5) Top-right far
            -1, -1, -1,     // (6) Bottom-left far
            1,  -1, -1      // (7) Bottom-right far
    };
    //4 5
    //0 1

    // 立方体索引
    private static final byte[] CubeIndex = new byte[] {
            // Front
            1, 3, 0,
            0, 3, 2,

            // Back
            4, 6, 5,
            5, 6, 7,

            // Left
            0, 2, 4,
            4, 2, 6,

            // Right
            5, 7, 1,
            1, 7, 3,

            // Top
            5, 1, 4,
            4, 1, 0,

            // Bottom
            6, 2, 7,
            7, 2, 3
    };

    private int mProgramHandle;
    private int mMatrixHandle;
    private int mTextureUnitHandle;
    private int mPositionHandle;

    // 天空盒纹理
    private int mSkyboxTexture;

    // 变换矩阵
    private float mMVPMatrix[] = new float[16];

    private FloatBuffer mVertexBuffer;
    private ByteBuffer mIndexBuffer;

    public SkyboxFilter() {
        mProgramHandle = GLUtils.createProgram(mVertexShader, mFragmentShader);

        mMatrixHandle = GLES20.glGetUniformLocation(mProgramHandle, "uMatrix");
        mTextureUnitHandle = GLES20.glGetUniformLocation(mProgramHandle, "uTextureUnit");
        mPositionHandle = GLES20.glGetAttribLocation(mProgramHandle, "aPosition");

//        String files[] = {
//                "/sdcard/left.jpg",
//                "/sdcard/right.jpg",
//                "/sdcard/bottom.jpg",
//                "/sdcard/top.jpg",
//                "/sdcard/front.jpg",
//                "/sdcard/back.jpg"};
        String files[] = {
                "/sdcard/back.jpg",
                "/sdcard/front.jpg",
                "/sdcard/bottom.jpg",
                "/sdcard/top.jpg",
                "/sdcard/left.jpg",
                "/sdcard/right.jpg"};
        mSkyboxTexture = GLUtils.loadCubeMap(files);

        mVertexBuffer = ByteBuffer.allocateDirect(CubeCoords.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        mVertexBuffer.put(CubeCoords).position(0);

        mIndexBuffer = ByteBuffer.allocateDirect(CubeIndex.length).order(ByteOrder.nativeOrder());
        mIndexBuffer.put(CubeIndex).position(0);

        float[] rotation = new float[16];
        Matrix.setIdentityM(rotation, 0);
        setRotationMatrix(rotation);
    }

    public void onSizeChanged(int width, int height) {
        GLES20.glViewport(0, 0, width, height);
    }

    public void onDraw() {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        //GLES20.glClearColor(0,1,1,1);

        GLES20.glUseProgram(mProgramHandle);

        // 变换矩阵
        GLES20.glUniformMatrix4fv(mMatrixHandle, 1, false, mMVPMatrix, 0);

        // 贴图
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_CUBE_MAP, mSkyboxTexture);
        GLES20.glUniform1i(mTextureUnitHandle, 0);

        // 顶点缓存
        GLES20.glEnableVertexAttribArray(mPositionHandle);
        GLES20.glVertexAttribPointer(mPositionHandle, COORDS_PER_VERTEX,
                GLES20.GL_FLOAT, false, 0, mVertexBuffer);

        // 顶点坐标
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, 36, GLES20.GL_UNSIGNED_BYTE, mIndexBuffer);

        GLES20.glUseProgram(0);
    }

    /**
     * 设置旋转矩阵
     */
    public void setRotationMatrix(float rotationMatrix[]) {
        float[] mViewMatrix = new float[16];    // 视图矩阵
        float[] mProjectionMatrix = new float[16]; // 投影矩阵

        // 计算综合矩阵
        Matrix.setIdentityM(mProjectionMatrix, 0);

        //设置相机位置
        Matrix.setIdentityM(mViewMatrix, 0);
        Matrix.setLookAtM(mViewMatrix, 0,
                0.0f, 0.0f, 0.0f,
                0.0f, 0.0f, -1.0f,
                0f, 1.0f, 0.0f);

        // 设置透视矩阵
        //float ratio = (float) width / (float) height;
        float ratio = (float) 720 / (float) 1280;
        GLUtils.perspectiveM(mProjectionMatrix, 45, ratio, 1f, 300f);

        Matrix.multiplyMM(mViewMatrix, 0, mViewMatrix, 0, rotationMatrix, 0);
        Matrix.rotateM(mViewMatrix, 0, 90, 1f, 0f, 0f);
        Matrix.multiplyMM(mMVPMatrix, 0, mProjectionMatrix, 0, mViewMatrix, 0);
    }

}