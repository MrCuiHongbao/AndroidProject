package cn.ubeta.gles_plugin

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.opengl.Matrix
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry.Registrar
import io.flutter.view.FlutterView

class GlesPlugin: MethodCallHandler, SensorEventListener {

  var textureRegistry: FlutterView

  //var glesInfos: HashMap<String, GLESThread>
  var glesInfos: HashMap<String, CameraRender>

  private var mSensorManager: SensorManager? = null
  private var mRotationSensor: Sensor? = null
  private val mRotationMatrix = FloatArray(16)

  companion object {
    @JvmStatic
    fun registerWith(registrar: Registrar) {
      val channel = MethodChannel(registrar.messenger(), "gles_plugin")
      channel.setMethodCallHandler(GlesPlugin(registrar))
    }
  }

  constructor(registrar: Registrar) {
    textureRegistry = registrar.view()
    glesInfos = HashMap()

    // 方向向量s
    mSensorManager = registrar.context().getSystemService(Context.SENSOR_SERVICE) as SensorManager
    mRotationSensor = mSensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    Matrix.setIdentityM(mRotationMatrix, 0)

    mSensorManager?.registerListener(this, mRotationSensor, SensorManager.SENSOR_DELAY_GAME)
  }

  override fun onMethodCall(call: MethodCall, result: Result) {
    if (call.method == "getPlatformVersion") {
      result.success("Android ${android.os.Build.VERSION.RELEASE}")
    } else if (call.method == "init") {
      // 初始化
      var surfaceTexture = textureRegistry.createSurfaceTexture()
      var textureId = surfaceTexture.id()
      //glesInfos[textureId.toString()] = GLESThread(textureRegistry.context, textureId.toString(), surfaceTexture.surfaceTexture(), 400, 800)
      glesInfos[textureId.toString()] = CameraRender(textureRegistry.context, textureId.toString(), surfaceTexture.surfaceTexture(), 400, 800)
      //glesInfos[textureId.toString()]?.start() // 启动线程
      result.success(textureId)
    } else if (call.method == "loadModel") {
      var ret = 0;
      ret = 1; // TODO 加载模型
      result.success(ret);
    } else if (call.method == "destroy") {
      // 销毁
      var textureId: Long? = call.argument("textureId")
      if (glesInfos[textureId.toString()] != null) {
        glesInfos[textureId.toString()]?.onSurfaceTextureDestroyed(null)
        glesInfos.remove(textureId.toString())
        result.success(0)
      } else {
        result.success(1)
      }
    } else {
      result.notImplemented()
    }
  }

  override
  fun onSensorChanged(event: SensorEvent) {
    SensorManager.getRotationMatrixFromVector(mRotationMatrix, event.values)

    glesInfos.forEach {
      it.key
      it.value.setRotationMatrix(mRotationMatrix)
    }
  }

  override
  fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
