package cn.ubeta.gles_plugin;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.SurfaceTexture;
import android.media.Image;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLES30;
import android.opengl.Matrix;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

public class CameraFilter {

    private static final String mVertexShader = "" +
            "uniform mat4 uMatrix;" +
            "attribute vec4 aTexCoordinate;" +
            "attribute vec2 aPosition;" +
            "varying vec2 vTexCoord;" +
            "void main() {" +
            "  vTexCoord = vec2(aTexCoordinate.x, 1.0-aTexCoordinate.y);" +
            "  gl_Position = uMatrix * vec4(aPosition, 1.0, 1.0);" +
            //"  gl_Position = vec4(aPosition, 1.0, 1.0);" +
            "}";

    private static final String mFragmentShader2 = "" +
            "#extension GL_OES_EGL_image_external : require\n" +
            "precision mediump float;" +
            //"uniform samplerExternalOES uTexture;" +
            "uniform sampler2D uTexture;" +
            "varying vec2 vTexCoord;" +
            "void main() {" +
            "  gl_FragColor = texture2D(uTexture, vTexCoord);" +
            //"  gl_FragColor = vec4(1.0, 1.0, 0.0, 1.0);" +
            "}";

    private static final String mFragmentShader = "" +
            "precision mediump float;" +
            "uniform sampler2D y_texture;" +
            "uniform sampler2D u_texture;" +
            "uniform sampler2D v_texture;" +
            "varying vec2 vTexCoord;" +
            "void main() {" +
            /*
            "    mediump float y;\n" +
            "    mediump float u;\n" +
            "    mediump float v;\n" +
            "    lowp  vec3 rgb;\n" +
            "    mat3 convmatrix = mat3(vec3(1.164,  1.164, 1.164),\n" +
            "                           vec3(0.0,   -0.392, 2.017),\n" +
            "                           vec3(1.596, -0.813, 0.0));\n" +
            "\n" +
            "    y = (texture2D(y_texture, vTexCoord).r - (16.0 / 255.0));\n" +
            "    u = (texture2D(u_texture, vTexCoord).r - (128.0 / 255.0));\n" +
            "    v = (texture2D(v_texture, vTexCoord).r - (128.0 / 255.0));\n" +
            "\n" +
            "    rgb = convmatrix * vec3(y, u, v);\n" +
            "    gl_FragColor = vec4(rgb, 1.0);" +
*/
            "   vec3 yuv;" +
            "   vec3 rgb;" +
            "   yuv.r = texture2D(y_texture, vTexCoord).r;" +
            "   yuv.g = texture2D(u_texture, vTexCoord).r - 0.5;" +
            "   yuv.b = texture2D(v_texture, vTexCoord).r - 0.5;" +
            //"     R = (int)(Y + 0* u + 1.140*V); \n" +
            //"     G = (int)(Y - 0.395*U - 0.581*V); \n" +
            //"     B = (int)(Y + 2.032*U + 0 * v); " +
            "   rgb = mat3(    1.0,      1.0,     1.0," +
            "                  2.032, -0.395,     0.0," +
            "                    0.0, -0.581,     0.0) * yuv;" +
            "   gl_FragColor = vec4(rgb, 1.0);" +

            //"  gl_FragColor = vec4(1.0, 1.0, 0.0, 1.0);" +
            "}";

    // 立方体坐标
    private static final float[] CubeCoords = new float[] {
            -1,  1,     // (0) Top-left near
            1,   1,     // (1) Top-right near
            -1, -1,     // (2) Bottom-left near
            1,  -1      // (3) Bottom-right near
    };
    //4 5
    //0 1

    // 立方体索引
    private static final byte[] CubeIndex = new byte[] {
            // Front
            0,1,2,3
    };

    private float[] RectCoord = {
            0.0f, 0.0f,
            0.0f, 1.0f,
            1.0f, 0.0f,
            1.0f, 1.0f
    };

    private int mProgramHandle;
    private int mMatrixHandle;
    private int mPositionHandle;
    private int mTextureHandle;
    private int mCoordAttLocation = -1;

    private int mTexture;

    private int mYTexture = -1;
    private int mUTexture = -1;
    private int mVTexture = -1;

    private int mTextureUniform0 = -1;
    private int mTextureUniform1 = -1;
    private int mTextureUniform2 = -1;

    // 变换矩阵
    private float mMVPMatrix[] = new float[16];

    private FloatBuffer mVertexBuffer;
    private ByteBuffer mIndexBuffer;

    private int mWidth, mHeight;

    int BYTES_PER_FLOAT = 4;

    private FloatBuffer mCoordData;


    public CameraFilter() {
        mProgramHandle = GLUtils.createProgram(mVertexShader, mFragmentShader);

        mMatrixHandle = GLES20.glGetUniformLocation(mProgramHandle, "uMatrix");
        mTextureHandle = GLES20.glGetUniformLocation(mProgramHandle, "uTexture");
        mPositionHandle = GLES20.glGetAttribLocation(mProgramHandle, "aPosition");
        mCoordAttLocation = GLES20.glGetAttribLocation(mProgramHandle, "aTexCoordinate");

        mTextureUniform0 = GLES20.glGetUniformLocation(mProgramHandle, "y_texture");
        mTextureUniform1 = GLES20.glGetUniformLocation(mProgramHandle, "u_texture");
        mTextureUniform2 = GLES20.glGetUniformLocation(mProgramHandle, "v_texture");

        final int[] textureObjectIds = new int[1];
        GLES20.glGenTextures(1, textureObjectIds, 0);
        mTexture = textureObjectIds[0];

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); //设置使用的纹理编号
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mTexture); //绑定指定的纹理id

        GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_NEAREST);//设置MIN 采样方式
        GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);//设置MAG采样方式
        GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);//设置S轴拉伸方式
        GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);//设置T轴拉伸方式

        //设置放大缩小。设置边缘测量
//        GLES20.glTexParameterf(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
//                GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_LINEAR);
//        GLES20.glTexParameterf(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
//                GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_LINEAR);
//        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
//                GL10.GL_TEXTURE_WRAP_S, GL10.GL_CLAMP_TO_EDGE);
//        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
//                GL10.GL_TEXTURE_WRAP_T, GL10.GL_CLAMP_TO_EDGE);

        //Bitmap bitmap = BitmapFactory.decodeFile("/sdcard/top.jpg");
        //android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);

        mVertexBuffer = ByteBuffer.allocateDirect(CubeCoords.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        mVertexBuffer.put(CubeCoords).position(0);

        mIndexBuffer = ByteBuffer.allocateDirect(CubeIndex.length).order(ByteOrder.nativeOrder());
        mIndexBuffer.put(CubeIndex).position(0);

        mCoordData = ByteBuffer.allocateDirect(RectCoord.length * Float.SIZE / 8).order(ByteOrder.nativeOrder()).asFloatBuffer();
        mCoordData.put(RectCoord).position(0);

        mYTexture = GLUtils.generateTexture(1);
        mUTexture = GLUtils.generateTexture(2);
        mVTexture = GLUtils.generateTexture(3);

        float[] rotation = new float[16];
        Matrix.setIdentityM(rotation, 0);
        setRotationMatrix(rotation);
    }

    public void onSizeChanged(int width, int height) {
        GLES20.glViewport(0, 0, width, height);
    }

    /**
     * 渲染
     * @param image 图像数据
     */
    public void onDraw(Image image, int format, int w, int h, Bitmap bitmap) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        //GLES20.glClearColor(0,1,1,1);

        GLES20.glUseProgram(mProgramHandle);

        // 变换矩阵
        GLES20.glUniformMatrix4fv(mMatrixHandle, 1, false, mMVPMatrix, 0);

        /*
        // 纹理贴图
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); //设置使用的纹理编号
        //GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTexture); //绑定指定的纹理id
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mTexture); //绑定指定的纹理id
        GLES20.glUniform1i(mTexture, 0);
        checkGlError("1");

        android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
        //GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGB565, w, h, 0, GLES20.GL_RGB565, GLES20.GL_UNSIGNED_BYTE, buf);
         */

        //我们可以将这帧数据转成字节数组，类似于Camera1的PreviewCallback回调的预览帧数据
        final Image.Plane[] planes = image.getPlanes();
        final ByteBuffer yBuffer = planes[0].getBuffer();
        final ByteBuffer uBuffer = planes[1].getBuffer();
        final ByteBuffer vBuffer = planes[2].getBuffer();

        yBuffer.position(0);
        uBuffer.position(0);
        vBuffer.position(0);

        GLES20.glActiveTexture(GLES20.GL_TEXTURE1);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mYTexture);
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_LUMINANCE, mWidth, mHeight, 0, GLES20.GL_LUMINANCE, GLES20.GL_UNSIGNED_BYTE, yBuffer);
        GLES20.glUniform1i(mTextureUniform0, 1);

        GLES20.glActiveTexture(GLES20.GL_TEXTURE2);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mUTexture);
        GLES30.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_LUMINANCE, mWidth, mHeight/2, 0, GLES20.GL_LUMINANCE, GLES20.GL_UNSIGNED_BYTE, uBuffer);
        GLES20.glUniform1i(mTextureUniform1, 2);

        GLES20.glActiveTexture(GLES20.GL_TEXTURE3);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mVTexture);
        GLES30.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_LUMINANCE, mWidth, mHeight/2, 0, GLES20.GL_LUMINANCE, GLES20.GL_UNSIGNED_BYTE, vBuffer);
        GLES20.glUniform1i(mTextureUniform2, 3);

        // 顶点缓存
        GLES20.glEnableVertexAttribArray(mPositionHandle);
        GLES20.glVertexAttribPointer(mPositionHandle, 2, GLES20.GL_FLOAT, false, 0, mVertexBuffer);
        checkGlError("2");

        // 纹理坐标
        GLES20.glEnableVertexAttribArray(mCoordAttLocation);
        GLES20.glVertexAttribPointer(mCoordAttLocation, 2, GLES20.GL_FLOAT, false, 0, mCoordData);
        checkGlError("3");

        // 顶点坐标
        GLES20.glDrawElements(GLES20.GL_TRIANGLE_STRIP, 4, GLES20.GL_UNSIGNED_BYTE, mIndexBuffer);
        //GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        checkGlError("4");

        SurfaceTexture x;

        GLES20.glUseProgram(0);
    }

    /**
     * 设置旋转矩阵
     */
    public void setRotationMatrix(float rotationMatrix[]) {
        float[] mViewMatrix = new float[16];    // 视图矩阵
        float[] mProjectionMatrix = new float[16]; // 投影矩阵

        //设置相机位置
        Matrix.setIdentityM(mViewMatrix, 0);
        Matrix.setLookAtM(mViewMatrix, 0,
                0.0f, 0.0f, 0.0f,
                0.0f, 0.0f, -1.0f,
                0f, 1.0f, 0.0f);

        // 设置透视矩阵
        //float ratio = (float) width / (float) height;
        float ratio = (float) 720 / (float) 1280;
        Matrix.setIdentityM(mProjectionMatrix, 0);
        GLUtils.perspectiveM(mProjectionMatrix, 45, ratio, 1f, 300f);

        Matrix.multiplyMM(mViewMatrix, 0, mViewMatrix, 0, rotationMatrix, 0);
        Matrix.rotateM(mViewMatrix, 0, 90, 1f, 0f, 0f);
        Matrix.multiplyMM(mMVPMatrix, 0, mProjectionMatrix, 0, mViewMatrix, 0);

        // TODO 图像暂时不旋转
        Matrix.setIdentityM(mMVPMatrix, 0);
        //Matrix.rotateM(mMVPMatrix, 0, 180, 1f, 0f, 0f);
    }

    public void setSize(int width, int height) {
        mWidth = width;
        mHeight = height;
    }

    public static void checkGlError(String op) {
        int error = GLES20.glGetError();
        if (error != GLES20.GL_NO_ERROR) {
            String msg = op + ": glError 0x" + Integer.toHexString(error);
            Log.e("checkGlError", msg);
            //throw new RuntimeException(msg);
        }
    }
}