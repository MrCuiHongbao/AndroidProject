//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <gles_plugin/GlesPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [GlesPlugin registerWithRegistrar:[registry registrarForPlugin:@"GlesPlugin"]];
}

@end
