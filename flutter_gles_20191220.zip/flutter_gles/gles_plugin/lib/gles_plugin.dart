import 'dart:async';

import 'package:flutter/services.dart';

class GlesPlugin {

  static const MethodChannel _channel = const MethodChannel('gles_plugin');

  static Future<String> get platformVersion async {
    final String version = await _channel.invokeMethod('getPlatformVersion');
    return version;
  }

  static Future<int> init() =>
      _channel.invokeMethod('init');

  static Future<int> loadModel(String filePath) =>
      _channel.invokeMethod('loadModel', {'filePath': filePath});

  static Future<void> destroy(int id) =>
      _channel.invokeMethod('destroy', {'id': id});
}
