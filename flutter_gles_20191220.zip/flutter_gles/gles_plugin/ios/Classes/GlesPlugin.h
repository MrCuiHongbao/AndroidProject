#import <Flutter/Flutter.h>

@interface GlesPlugin : NSObject<FlutterPlugin>
@end
