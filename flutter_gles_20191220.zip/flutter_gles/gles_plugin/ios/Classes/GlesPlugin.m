#import "GlesPlugin.h"
#import <gles_plugin/gles_plugin-Swift.h>

@implementation GlesPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {
  [SwiftGlesPlugin registerWithRegistrar:registrar];
}
@end
