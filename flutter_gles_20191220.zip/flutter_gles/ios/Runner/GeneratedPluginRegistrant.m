//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<gles_plugin/GlesPlugin.h>)
#import <gles_plugin/GlesPlugin.h>
#else
@import gles_plugin;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [GlesPlugin registerWithRegistrar:[registry registrarForPlugin:@"GlesPlugin"]];
}

@end
